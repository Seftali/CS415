<?php include("server.php"); 

if(empty($_SESSION["username"]))
{
	header('location: main.php');
}
else
{
	header('location: homepage.php');
}
?>
