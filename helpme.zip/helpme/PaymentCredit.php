<?php include("server.php"); 

if(empty($_SESSION["username"]))
{
  header('location: main.php');
}
$proID = $_SESSION['userid'];
$query = "SELECT user_id FROM professional where user_id = '$proID'";
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) == 1){
  header('location: requests.php');
}
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://v40.pingendo.com/assets/4.0.0/default/theme.css" type="text/css"> </head>

  <body>
    <nav class="navbar navbar-expand-md bg-primary navbar-dark">
      <a class="navbar-brand">
        <b>
          <b>HelpMe</b>
        </b>
      </a>
      <div class="container">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">

          <!--<a class="btn btn-default navbar-btn btn-light text-secondary">Profile</a> -->
          <a class="btn btn-default navbar-btn btn-light text-secondary" href="customer_profile.php">
            <i class="fa d-inline fa-lg fa-user-circle-o"></i>Profile
            <a class="btn navbar-btn ml-2 text-white btn-secondary" href="index.php?logout='1'">
              <i class="fa d-inline fa-lg fa-user-circle-o"></i>Log Out
              <br></a>
              <br></a>
            </div>
          </div>
        </nav>
        <nav class="navbar navbar-expand-md bg-secondary navbar-dark">
      <div class="container">
        <a class="navbar-brand" href="#">
          <b>Home Page <br>
          </b>
        </a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
              <li class="nav-item text-light">
                <a class="nav-link" href="homepage.php">CourseList</a>
              </li>
              <li class="nav-item text-light">
                <a class="nav-link" href="takenJobs.php">Taken Courses</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-center display-3 text-primary">Credit Card</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <table class="table">
            <tbody>
              <tr></tr>
              <tr></tr>
              <tr></tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6"><img class="img-fluid d-block w-100" src="indir.png"></div>
        <div class="col-md-6">
          <form id="c_form-h" class="" action="homepage.php">
            <div class="form-group row"> <label for="inputmailh" class="col-2 col-form-label">Card Number</label>
              <div class="col-10">
                <input type="" class="form-control py-2" id="inputmailh" style=""> </div>
            </div>
            <div class="form-group row"> <label for="inputpasswordh" class="col-2 col-form-label" contenteditable="true">CV Code</label>
              <div class="col-10">
                <input type="" class="form-control" id="inputpasswordh"> </div>
            </div>
            <div class="form-group row"> <label for="inputmailh" class="col-2 col-form-label" contenteditable="true">Exp Date</label>
              <div class="col-10">
                <input type="" class="form-control" id="inputmailh"> </div>
            </div>
            <div class="form-group row"> <label for="inputpasswordh" class="col-2 col-form-label">Name On Card</label>
              <div class="col-10">
                <input type="" class="form-control" id="inputpasswordh"> </div>
            </div>
            <button type="submit" class="btn btn-primary">Complete Payment</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="bg-dark text-white">
    <div class="container">
      <div class="row">
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">HelpMe</h2>
          <p class="text-white">A company for whatever you may need, private courses!!</p>
        </div>
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">Mapsite</h2>
          <ul class="list-unstyled">
              <a href="homepage.php" class="text-white">CourseList</a>
              <br>
              <a href="takenJobs.php" class="text-white">Taken Courses</a>
            </ul>
        </div>
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">Contact</h2>
          <p>
            <a href="mailto:info@pingendo.com" class="text-white">
              <i class="fa d-inline mr-3 text-secondary fa-envelope-o"></i>h</a>elpme42@gmail.com</p>
          <p>
            <a href="https://goo.gl/maps/AUq7b9W7yYJ2" class="text-white" target="_blank">
              <i class="fa d-inline mr-3 fa-map-marker text-secondary"></i>B</a>ilkent University</p>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <pingendo onclick="window.open('https://pingendo.com/', '_blank')" style="cursor:pointer;position: fixed;bottom: 20px;right:20px;padding:4px;background-color: #00b0eb;border-radius: 8px; width:220px;display:flex;flex-direction:row;align-items:center;justify-content:center;font-size:14px;color:white">Made with Pingendo Free&nbsp;&nbsp;<img src="https://pingendo.com/site-assets/Pingendo_logo_big.png" class="d-block" alt="Pingendo logo" height="16"></pingendo>
</body>

</html>