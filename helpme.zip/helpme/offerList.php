<?php include("server.php"); 

if(empty($_SESSION["username"]))
{
	header('location: login.php');
}

?>
<!DOCTYPE html>

<html>
<head>
	<title>RequestPage</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<meta charset="description" content="Google alt metin">
	<meta charset="keyword" content="Google keyword">
	<meta charset="author" content="Muammer">
	<meta charset="viewport" content="width-device-width, initial-scale-1.0">

</head>

<body>
	<ul>
		<li><a class="active" href="#">Home</a></li>
		<li><a class="active" href="profile.php">Profile</a></li>
		<li><a href="#contact">Contact</a></li>
		<li><a class="active" href="request.php">Category</a></li>
		<li><a href="#about">About</a></li>
		<li style="float:right"><a class="active" href="index.php?logout='1'">Logout</a></li>
	</ul>
	<div class="header" style="width:90%">
		<h2>OfferList</h2>		
	</div>
	<div style="display:  flex;justify-content:  center;padding: 20px;">
		<table style="width:90%">
			<tr>
				<th>Service Name</th>
				<th>Proffesional Name</th>
				<th>Information</th> 
				<th>Price</th>
			</tr>
			<?php 
				//connection
			$db = mysqli_connect("localhost", "root", "", "helpme");
			$usernameForRequestList = $_SESSION["username"];

			//SELECT consumer.name, consumer.surname, request.time_interval,request.information FROM user,request,consumer WHERE request.consumer_id = consumer.consumer_id && consumer.consumer_id= user.id && user.city_id = '5' && request.subcategory_id = '1' && request.isTaken = '0'
			
			//$profSubCategoryID = 1;
			$sql1 = "SELECT consumer_id FROM consumer,user WHERE user.id = consumer.consumer_id && user.username='$usernameForRequestList'";
			
			//taking subcategoryID of current user which is proffesional
			$consIdTable=mysqli_query($db, $sql1);
			$result1 = mysqli_fetch_assoc($consIdTable);
			
			$consID = $result1['consumer_id'];
			
			
			$sql2 = "SELECT offer.information, professional.company_name, subcategory.subcategory_name, offer.price FROM offer,request,professional,subcategory WHERE request.consumer_id = '$consID' && request.request_id = offer.request_id && offer.professional_id = professional.user_id && request.subcategory_id = subcategory.subcategory_id";
			$consIdTable2 = mysqli_query($db, $sql2);
			while($row = mysqli_fetch_assoc($consIdTable2)){   //Creates a loop to loop through results
				//echo "dsadas";
				echo "<tr><td>" . $row['subcategory_name'] . "</td><td>" . $row['company_name'] . "</td> <td>" . $row['information'] . "</td><td>" . $row['price'] . "</td></tr>";  //$row['index'] the index here is a field name
			}
			header('location: professional_profile.php');

?>

		</table>
	</div>

</body>
</html>