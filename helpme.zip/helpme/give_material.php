<?php include("server.php"); 

if(empty($_SESSION["username"]))
{
  header('location: main.php');
}
$proID = $_SESSION['userid'];
$query = "SELECT consumer_id FROM consumer where consumer_id = '$proID'";
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) == 1){
  header('location: homepage.php');
}

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://v40.pingendo.com/assets/4.0.0/default/theme.css" type="text/css">
</head>

<body>
  <nav class="navbar navbar-expand-md bg-primary navbar-dark">
    <a class="navbar-brand">
      <b>
        <b>HelpMe</b>
      </b>
    </a>
    <div class="container">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
        <a class="btn navbar-btn ml-2 text-white btn-secondary" href="index.php?logout='1'">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>Log Out <br>
        </a>
        <a class="btn btn-default navbar-btn btn-light text-secondary" href="professional_profile.php">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>Profile <br> </a>
        </div>
      </div>
    </nav>
    <nav class="navbar navbar-expand-md bg-secondary navbar-dark">
      <div class="container">
        <a class="navbar-brand" href="requests.php">
          <b>Home Page <br>
          </b>
        </a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item text-light">
              <a class="nav-link" href="givenJobs.php">Given Courses</a>
            </li>
            <li class="nav-item text-light">
              <a class="nav-link" href="#">Create Course</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <div class="py-2" style="">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-center display-3 text-primary">Give Meterial</h1>
        </div>
      </div>
    </div>
  </div>
  <div class="py-2">
    <div class="container">
      <div class="row">
        <div class="col-md-12" style="">
          <div class="card">
            <div class="card-header"> Enter Text Here ( Links, Reccomendations etc.), Upload .pdf,&nbsp; .word (max size 20mb)</div>
            <div class="card-body" style="">
              <p class="">Paragraph. Then, my friend, when darkness overspreads my eyes, and heaven and earth seem to dwell in my soul and absorb its power, like the form of a beloved mistress, then I often think with longing.Paragraph. Then, my friend, when darkness overspreads my eyes, and heaven and earth seem to dwell in my soul and absorb its power, like the form of a beloved mistress, then I often think with longing.Paragraph. Then, my friend, when darkness overspreads my eyes, and heaven and earth seem to dwell in my soul and absorb its power, like the form of a beloved mistress, then I often think with longing.Paragraph. Then, my friend, when darkness overspreads my eyes, and heaven and earth seem to dwell in my soul and absorb its power, like the form of a beloved mistress, then I often think with longing.Paragraph. Then, my friend, when darkness overspreads my eyes, and heaven and earth seem to dwell in my soul and absorb its power, like the form of a beloved mistress, then I often think with longing.<br><br>https://moodle.bilkent.edu.tr/2018-2019-spring/pluginfile.php/221780/mod_resource/content/1/SPLE%20Term%20Project-Phase%20II-Spring2019.pdf</p>
            </div>
          </div><img class="img-fluid d-block w-25 h-25" src="https://static.pingendo.com/img-placeholder-1.svg">
        </div>
      </div>
      <div class="row">
        <div class="col-md-12" style=""><a class="btn btn-primary" href="#">Choose File to Upload</a></div>
      </div>
      <div class="row">
        <div class="col-md-12" style=""><a class="btn btn-primary px-1" href="#">Upload</a></div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <form class="form-inline">
            <div class="form-group">
              <input type="email" class="form-control" id="inputmailinline" placeholder="E-mail"> </div>
            <button type="submit" class="btn btn-primary ">Done</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="bg-dark text-white">
    <div class="container">
      <div class="row">
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">HelpMe</h2>
          <p class="text-white">A company for whatever you may need, from house cleaning to private course.</p>
        </div>
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">Mapsite</h2>
          <ul class="list-unstyled">
              <a href="requests.php" class="text-white">Home Page</a>
              <br>
              <a href="givenJobs.php" class="text-white">Given Courses</a>
              <br>
              <a href="createCourse.php" class="text-white">Create Course</a>
            </ul>
        </div>
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">Contact</h2>
          <p>
            <a href="mailto:info@pingendo.com" class="text-white">
              <i class="fa d-inline mr-3 text-secondary fa-envelope-o"></i>h</a>elpme42@gmail.com</p>
          <p>
            <a href="https://goo.gl/maps/AUq7b9W7yYJ2" class="text-white" target="_blank">
              <i class="fa d-inline mr-3 fa-map-marker text-secondary"></i>B</a>ilkent University</p>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <pingendo onclick="window.open('https://pingendo.com/', '_blank')" style="cursor:pointer;position: fixed;bottom: 20px;right:20px;padding:4px;background-color: #00b0eb;border-radius: 8px; width:220px;display:flex;flex-direction:row;align-items:center;justify-content:center;font-size:14px;color:white">Made with Pingendo Free&nbsp;&nbsp;<img src="https://pingendo.com/site-assets/Pingendo_logo_big.png" class="d-block" alt="Pingendo logo" height="16"></pingendo>
</body>

</html>