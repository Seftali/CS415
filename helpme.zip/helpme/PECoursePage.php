<?php include("server.php"); 

if(empty($_SESSION["username"]))
{
  header('location: main.php');
}
$proID = $_SESSION['userid'];
$query = "SELECT user_id FROM professional where user_id = '$proID'";
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) == 1){
  header('location: requests.php');
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://v40.pingendo.com/assets/4.0.0/default/theme.css" type="text/css">
</head>

<body>
  <nav class="navbar navbar-expand-md bg-primary navbar-dark">
    <a class="navbar-brand" href="#">
      <b>
        <b>HelpMe</b>
      </b>
    </a>
    <div class="container">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
        <a class="btn navbar-btn ml-2 text-white btn-secondary" href="index.php?logout='1'">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>Log Out <br>
        </a>
        <a class="btn btn-default navbar-btn btn-light text-secondary" href="customer_profile.php">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>Profile <br> </a>
        </div>
      </div>
    </nav>
    <nav class="navbar navbar-expand-md bg-secondary navbar-dark">
      <div class="container">
        <a class="navbar-brand" href="#">
          <b>Home Page <br>
          </b>
        </a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item text-light">
              <a class="nav-link" href="homepage.php">CourseList</a>
            </li>
            <li class="nav-item text-light">
              <a class="nav-link" href="takenJobs.php">Taken Courses</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="py-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="text-center display-3 text-primary">PE Course</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <table class="table">
              <tbody>
                <tr>
                  <th>Course Type</th>
                  <th>Tutor Name</th>
                  <th>Information</th>
                  <th>Price</th>
                  <th>Selection</th>
                </tr>
                <tr></tr>
                <tr></tr>
                <tr>
                  <td>Physical</td>
                  <td>Usain Bolt</td>
                  <td>Running</td>
                  <td>600</td>
                  <td><a class="btn btn-primary" style="text-decoration:  none;" href="EnrollPage.php">Enroll</a></td>
                </tr>
                <tr></tr>
                <tr></tr>
                <tr></tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="py-5" style="">
      <div class="container">
        <div class="row">
          <div class="col-md-6" style="">
            <div class="card-header"> Information About Instructor</div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6" style="">
            <div class="card">
              <div class="card-body w-100 h-50">
                <h4>Hello<br><br>Jamaican retired sprinter. He is a world record holder in the 100 metres, 200 metres and 4 × 100 metres relay. His reign as Olympic Games champion in all of these events spans three Olympics. Owing to his achievements and dominance in sprint competition, he is widely considered to be the greatest sprinter of all time.</h4>
                <p>Some quick example text to build on the card title .</p>
              </div>
            </div>
          </div>
          <div class="col-md-6" style=""><img class="img-fluid d-block w-50" src="I180107_182030_1998210oTextTRMRMMGLPICT000070669377o.jpg" width="50"></div>
        </div>
      </div>
    </div>
    <div class="py-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="list-group">
              <a href="#" class="list-group-item list-group-item-action active"> Personal Information</a>
              <a href="#" class="list-group-item list-group-item-action">Name&nbsp; &nbsp;: Usain Bolt</a>
              <a href="#" class="list-group-item list-group-item-action">Age&nbsp; &nbsp; &nbsp; : 32</a>
              <a href="#" class="list-group-item list-group-item-action">Email&nbsp; &nbsp; : usain@bolt.com</a>
              <a href="#" class="list-group-item list-group-item-action disabled" style="">Lives In : Istanbul</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="bg-dark text-white">
      <div class="container">
        <div class="row">
          <div class="p-4 col-md-4">
            <h2 class="mb-4 text-secondary">HelpMe</h2>
            <p class="text-white">A company for whatever you may need, private courses!!</p>
          </div>
          <div class="p-4 col-md-4">
            <h2 class="mb-4 text-secondary">Mapsite</h2>
            <ul class="list-unstyled">
              <a href="homepage.php" class="text-white">CourseList</a>
              <br>
              <a href="takenJobs.php" class="text-white">Taken Courses</a>
            </ul>
          </div>
          <div class="p-4 col-md-4">
            <h2 class="mb-4 text-secondary">Contact</h2>
            <p>
              <a href="mailto:info@pingendo.com" class="text-white">
                <i class="fa d-inline mr-3 text-secondary fa-envelope-o"></i>h</a>elpme42@gmail.com</p>
                <p>
                  <a href="https://goo.gl/maps/AUq7b9W7yYJ2" class="text-white" target="_blank">
                    <i class="fa d-inline mr-3 fa-map-marker text-secondary"></i>B</a>ilkent University</p>
                  </div>
                </div>
              </div>
            </div>
            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
            <pingendo onclick="window.open('https://pingendo.com/', '_blank')" style="cursor:pointer;position: fixed;bottom: 20px;right:20px;padding:4px;background-color: #00b0eb;border-radius: 8px; width:220px;display:flex;flex-direction:row;align-items:center;justify-content:center;font-size:14px;color:white">Made with Pingendo Free&nbsp;&nbsp;<img src="https://pingendo.com/site-assets/Pingendo_logo_big.png" class="d-block" alt="Pingendo logo" height="16"></pingendo>
          </body>

          </html>