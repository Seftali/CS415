<?php include("server.php"); 

if(empty($_SESSION["username"]))
{
  header('location: main.php');
}
$proID = $_SESSION['userid'];
$query = "SELECT consumer_id FROM consumer where consumer_id = '$proID'";
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) == 1){
  header('location: homepage.php');
}

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://v40.pingendo.com/assets/4.0.0/default/theme.css" type="text/css">
</head>

<body>
  <nav class="navbar navbar-expand-md bg-primary navbar-dark">
    <a class="navbar-brand">
      <b>
        <b>HelpMe</b>
      </b>
    </a>
    <div class="container">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
        <a class="btn navbar-btn ml-2 text-white btn-secondary" href="index.php?logout='1'">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>Log Out <br>
        </a>
        <a class="btn btn-default navbar-btn btn-light text-secondary" href="professional_profile.php">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>Profile <br> </a>
        </div>
      </div>
    </nav>
    <nav class="navbar navbar-expand-md bg-secondary navbar-dark">
      <div class="container">
        <a class="navbar-brand" href="requests.php">
          <b>Home Page <br>
          </b>
        </a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item text-light">
              <a class="nav-link" href="givenJobs.php">Given Courses</a>
            </li>
            <li class="nav-item text-light">
              <a class="nav-link" href="#">Create Course</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <div class="py-2" style="">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-center display-3 text-primary">Course you Teach</h1>
        </div>
      </div>
    </div>
  </div>
  <div class="py-2">
    <div class="container">
      <div class="row">
        <div class="col-md-12 py-2"><a class="btn btn-primary" href="give_material.php">Give Material</a></div>
      </div>
      <?php 
        $query = "SELECT subcategory_id FROM professional where user_id = '$proID'";
        $result = mysqli_query($db, $query);
        $row = mysqli_fetch_assoc($result);
        $subId = $row['subcategory_id'];
        if($subId == 1){
          echo "<div class=\"col-md-12 py-2\"><a class=\"btn btn-primary\" href=\"\HWandPracSchedular.php\" contenteditable=\"true\">HomeWorkSchedular</a></div>";
        }
        else{
          echo "<div class=\"row\"><div class=\"row\">
        <div class=\"col-md-12 py-2\"><a class=\"btn btn-primary\" href=\"HWandPracSchedular.php\">Weekly Practice Schedular</a></div>
      </div>";
        }
      ?>
        
    </div>
  </div>
  <div class="py-2">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header"> Student Information</div>
            <div class="card-body">
              <div class="card-body">
                <h5 class="card-title">Name</h5>
                <p class="card-text">Berk Ataç</p>
              </div>
            </div>
            <li class="list-group-item" style="">
              <h4 class="">Back Ground Information&nbsp;</h4>After graduating from high school in 1972, Jobs attended Reed College in Portland, Oregon, for two years. He dropped out after one semester to visit India and study eastern religions in the summer of 1974. In 1975 Jobs joined a group known as the Homebrew Computer Club. One member, a technical whiz named Steve Wozniak (1950–), was trying to build a small computer. Jobs became fascinated with the marketing potential of such a computer. In 1976 he and Wozniak formed their own company. They called it Apple Computer Company, in memory of a happy summer Jobs had spent picking apples. They raised $1,300 in startup money by selling Jobs's microbus and Wozniak's calculator. At first they sold circuit boards (the boards that hold the internal components of a computer) while they worked on the computer prototype.
            </li>
            <li class="list-group-item">
              <h4 class="">City</h4>Ankara
            </li>
            <li class="list-group-item">
              <h4 class="">Age</h4>25
            </li>
            <div class="card-body">
              <a href="#" class="card-link">email@email.com</a>
              <a href="#" class="card-link">+905321456985</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="py-2">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="">Your Schedule</h1><a class="btn btn-primary" href="#">Edit</a>
        </div>
      </div>
    </div>
  </div>
  <div class="asd">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="table-responsive">
            <table class="table table-striped table-borderless">
              <thead>
                <tr>
                  <th scope="col">Monday</th>
                  <th scope="col">Tuesday</th>
                  <th scope="col">Wednesday</th>
                  <th>Thursday</th>
                  <th>Friday</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="13">-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                </tr>
                <tr>
                  <td style="">-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>10.00-12.00(v)</td>
                  <td>-</td>
                </tr>
                <tr>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                </tr>
                <tr>
                  <td>14.00-16.00(v)</td>
                  <td>-</td>
                  <td>14.00-16.00</td>
                  <td>-</td>
                  <td>-</td>
                </tr>
                <tr>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>16.00-18.00</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="py-2">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="">Video Session (Requires Camera)</h1><a class="btn btn-primary" href="#">Connect</a>
        </div>
      </div>
    </div>
  </div>
  <div class="py-2">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="embed-responsive embed-responsive-16by9">
            <video src="https://static.pingendo.com/video-placeholder.mp4" class="embed-responsive-item" controls="controls"> Your browser does not support HTML5 video. </video>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="bg-dark text-white">
    <div class="container">
      <div class="row">
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">HelpMe</h2>
          <p class="text-white">A company for whatever you may need, from house cleaning to private course.</p>
        </div>
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">Mapsite</h2>
          <ul class="list-unstyled">
              <a href="requests.php" class="text-white">Home Page</a>
              <br>
              <a href="givenJobs.php" class="text-white">Given Courses</a>
              <br>
              <a href="createCourse.php" class="text-white">Create Course</a>
            </ul>
          </ul>
        </div>
        <div class="p-4 col-md-4">
          <h2 class="mb-4 text-secondary">Contact</h2>
          <p>
            <a href="mailto:info@pingendo.com" class="text-white">
              <i class="fa d-inline mr-3 text-secondary fa-envelope-o"></i>h</a>elpme42@gmail.com</p>
          <p>
            <a href="https://goo.gl/maps/AUq7b9W7yYJ2" class="text-white" target="_blank">
              <i class="fa d-inline mr-3 fa-map-marker text-secondary"></i>B</a>ilkent University</p>
        </div>
      </div>
    </div>
  </div>
  
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <pingendo onclick="window.open('https://pingendo.com/', '_blank')" style="cursor:pointer;position: fixed;bottom: 20px;right:20px;padding:4px;background-color: #00b0eb;border-radius: 8px; width:220px;display:flex;flex-direction:row;align-items:center;justify-content:center;font-size:14px;color:white">Made with Pingendo Free&nbsp;&nbsp;<img src="https://pingendo.com/site-assets/Pingendo_logo_big.png" class="d-block" alt="Pingendo logo" height="16"></pingendo>
</body>

</html>