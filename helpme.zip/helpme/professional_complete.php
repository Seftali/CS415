<?php include("server.php"); 

if(empty($_SESSION["username"]))
{
  header('location: main.php');
}
$proID = $_SESSION['userid'];
$query = "SELECT consumer_id FROM consumer where consumer_id = '$proID'";
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) == 1){
  header('location: homepage.php');
}

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://v40.pingendo.com/assets/4.0.0/default/theme.css" type="text/css"> 
</head>

<body>
  <div class="bg-primary text-white py-5 h-100" >
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="col-md-9">
            <h1>We need more info about you!</h1>
            <p>Please fill the following form to continue</p>
            <form method="post" action="professional_complete.php">
              <div class="form-group">
                <label>Your Name and Surname</label>
                <input type="text" class="form-control" placeholder="Name" name="name" required=""> 
              </div>
              <div class="form-group">
                <label>Enter Information About Yourself</label>
                <textarea class="form-control" name="info" rows="3" required=""></textarea>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Choose a category to be tutor</label>
                <select class="custom-control custom-select" required name="sub">
                  <option selected="" value="">Categories</option>
                  <option value="1">Educational Course</option>
                  <option value="2">Physical Course</option>
                  <option value="3">Instrumental Course</option>
                </select>
              </div>
              <button type="submit" class="btn btn-secondary" name="professional_complete">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>